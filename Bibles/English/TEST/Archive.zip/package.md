#Language
English
#Version
Unlocked Literal Bible
#Source
Unfolding Word
#License
CCSA
#Year
2016
